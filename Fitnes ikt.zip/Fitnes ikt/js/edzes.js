class Edzes {
    #nev
    #izomcsoport
    #nehezsegiSzint
    #sorozatok
    #ismetlesek
    #pihenesiIdo
    #suly

      constructor(nev, izomcsoport, nehezsegiSzint, sorozatok, ismetlesek, pihenesiIdo, suly) {
        this.setNev(nev)
        this.setIzomcsoport(izomcsoport)
        this.setNehezsegiSzint(nehezsegiSzint)
        this.setSorozatok(sorozatok)
        this.setIsmetlesek(ismetlesek)
        this.setPihenesiIdo(pihenesiIdo)
        this.setSuly(suly)
    }

    setNev(nev) {
        if (nev.length < 5) {
            this.#nev = "Ismeretlen gyakorlat"
        } else {
            this.#nev = nev
        }
    }

    setIzomcsoport(izomcsoport) {
        this.#izomcsoport = izomcsoport
    }

    setNehezsegiSzint(nehezsegiSzint) {
        this.#nehezsegiSzint = nehezsegiSzint
    }

setSorozatok(sorozatok) {
    sorozatok = Number(sorozatok)
    if (sorozatok < 0) {
        this.#sorozatok = 0
    } else if (sorozatok > 10) {
        this.#sorozatok = 10
    } else {
        this.#sorozatok = sorozatok
    }
}

setIsmetlesek(ismetlesek) {
    ismetlesek = Number(ismetlesek)
    if (ismetlesek < 0) {
        this.#ismetlesek = 0
    } else if (ismetlesek > 20) {
        this.#ismetlesek = 20
    } else {
        this.#ismetlesek = ismetlesek
    }
}

setPihenesiIdo(pihenesiIdo) {
    pihenesiIdo = Number(pihenesiIdo)
    if (pihenesiIdo < 0) {
        this.#pihenesiIdo = 0
    } else if (pihenesiIdo > 600) {
        this.#pihenesiIdo = 600
    } else {
        this.#pihenesiIdo = pihenesiIdo
    }
}

setSuly(suly) {
    suly = Number(suly)
    if (suly < 0) {
        this.#suly = 0
    } else if (suly > 500) {
        this.#suly = 500
    } else {
        this.#suly = suly
    }
}

     getSuly() {
        return this.#suly
    }

    
    getNev() {
        return this.#nev
    }

    getIzomcsoport() {
        return this.#izomcsoport
    }

    getNehezsegiSzint() {
        return this.#nehezsegiSzint
    }

    getSorozatok() {
        return this.#sorozatok
    }

    getIsmetlesek() {
        return this.#ismetlesek
    }

    getPihenesiIdo() {
        return this.#pihenesiIdo
    }
}