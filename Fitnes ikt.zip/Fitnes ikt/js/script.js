var mentettek = []
var reszletIndex = -1
var lista = [];
var beallitasok = [];
var izomcsoportok = ["Mell", "Hát", "Váll", "Bicepsz", "Tricepsz", "Alkar", "Comb", "Farizom", "Vádli", "Has", "Teljes test", "Kardió"]
var torlendo = -1

function napNeve(i){
    if (i === 0) return "Ma"
    if (i === 1) return "Tegnap"
    var napok = ["Vasárnap","Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat"]
    var datum = new Date()
    datum.setDate(datum.getDate() - i)
    return napok[datum.getDay()]
}

function Uzenet(szoveg){
    document.querySelector("#uzenetToast .uzenetSzoveg").textContent = szoveg // szinten ai
    bootstrap.Toast.getOrCreateInstance(document.getElementById("uzenetToast")).show()
}

function ProfilMutat(){
    document.querySelector("#epitoNezet").classList.add("d-none")
    document.querySelector("#profil").classList.remove("d-none")
    kiirProfil()
    kiirMentettek()
    frissitNev()

    document.querySelector(".profilGomb i").className = "bi bi-hammer"
    document.querySelector(".profilGomb .label-long").textContent = "Építő"
    document.querySelector(".profilGomb .label-short").textContent = "Építő"
}

function EpitoMutat(){
    document.querySelector("#profil").classList.add("d-none")
    document.querySelector("#epitoNezet").classList.remove("d-none")

    document.querySelector(".profilGomb i").className = "bi bi-person"
    document.querySelector(".profilGomb .label-long").textContent = "Profil"
    document.querySelector(".profilGomb .label-short").textContent = "Profil"
}

function kiirProfil(){
    document.querySelector(".total-edzes").textContent = mentettek.length

    document.querySelector(".heti-naplo").innerHTML = ""
    if (mentettek.length === 0) {
        document.querySelector(".heti-naplo").innerHTML = `<tr><td colspan="5" class="profil-sub text-center">Még nincs edzésed</td></tr>`
    } else {
        for (let i = 0; i < mentettek.length; i++) {
            var osszMasodperc = 0
            var osszSuly = 0
            for (let j = 0; j < mentettek[i].gyakorlatok.length; j++) {
                var gyakorlat = mentettek[i].gyakorlatok[j]
                osszMasodperc += gyakorlat.getSorozatok() * (gyakorlat.getIsmetlesek() * 3 + gyakorlat.getPihenesiIdo())
                osszSuly += gyakorlat.getSorozatok() * gyakorlat.getIsmetlesek() * gyakorlat.getSuly()
            }
            var perc = Math.round(osszMasodperc / 60)

            document.querySelector(".heti-naplo").innerHTML += `
                <tr>
                    <td>${napNeve(i)}</td>
                    <td>${mentettek[i].nev}</td>
                    <td>${perc} perc</td>
                    <td>${osszSuly} kg</td>
                    <td>Kész</td>
                </tr>`
        }
    }

    document.querySelector(".szemelyes-rekordok").innerHTML = ""

    if (mentettek.length === 0) {
        document.querySelector(".szemelyes-rekordok").innerHTML = `<tr><td colspan="3" class="profil-sub text-center">Még nincs rekord</td></tr>`
    } else {
        var legjobb = mentettek[0].gyakorlatok[0]
        var izom = legjobb.getIzomcsoport()

        for (let i = 0; i < mentettek.length; i++) {
            for (let j = 0; j < mentettek[i].gyakorlatok.length; j++) {
                var gyakorlat = mentettek[i].gyakorlatok[j]
                if (gyakorlat.getIzomcsoport() === izom && gyakorlat.getSuly() > legjobb.getSuly()) {
                    legjobb = gyakorlat
                }
            }
        }

        document.querySelector(".szemelyes-rekordok").innerHTML = `
            <tr>
                <td>${legjobb.getNev()} <span class="profil-sub small">· ${izom}</span></td>
                <td>${legjobb.getSuly()} kg</td>
                <td>${legjobb.getIsmetlesek()}</td>
            </tr>`
    }
}

function kiirMentettek(){
    var szoveg = ""
    for (let i = 0; i < mentettek.length; i++) {
        var nevek = ""
        for (let j = 0; j < mentettek[i].gyakorlatok.length; j++) {
            nevek += mentettek[i].gyakorlatok[j].getNev() + ", "
        }
        szoveg += `
        <div class="mb-3">
            <p class="fw-semibold mb-0">${mentettek[i].nev}</p>
            <p class="profil-sub small mb-0">${mentettek[i].gyakorlatok.length} gyakorlat: ${nevek.slice(0, -2)}</p>
        </div>`
    }
    if (szoveg === "") {
        szoveg = `<p class="profil-sub mb-0">Még nincs mentett edzésterv.</p>`
    }
    document.querySelector(".mentettek").innerHTML = szoveg
}

function kiirFeladat(){
    kiirSzurt(f => true)
}

function kiirSzurt(feltetel) {
    document.querySelector(".feladatok").innerHTML = "";
    for (let i = 0; i < feladatok.length; i++) {
        if (feltetel(feladatok[i])) {
            document.querySelector(".feladatok").innerHTML += `
            <div class="exercise-row d-flex align-items-center gap-3 mb-3">
              <button type="button" class="catalog-item flex-grow-1" data-bs-toggle="modal" data-bs-target="#reszletModal" onclick="ReszletMutat(${i})">
                <span class="fw-semibold d-block">${feladatok[i].getNev()}</span>
                <span class="profil-sub small">${feladatok[i].getIzomcsoport()} · ${feladatok[i].getNehezseg()}</span>
              </button>
              <button type="button" class="mini-btn hozzaad" aria-label="Hozzáadás" onclick="Felvesz(${i})"><i class="bi bi-plus-lg"></i></button>
            </div>`;
        }
    }
}

function kiirIzomGombok(){
    document.querySelector(".izomGombok").innerHTML = ""
    for (let i = 0; i < izomcsoportok.length; i++) {
        document.querySelector(".izomGombok").innerHTML += `<button type="button" class="btn builder-ghost btn-sm m-2" onclick="SzuroIzom('${izomcsoportok[i]}')">${izomcsoportok[i]}</button>`
    }
}

function SzuroIzom(izom){
    kiirSzurt(f => f.getIzomcsoport() === izom)
}

function ReszletMutat(i){
    reszletIndex = i
    var gyakorlat = feladatok[i]
    var cimkek = document.querySelectorAll("#reszletModal .badge-pill")

    document.querySelector("#reszletModal h3").textContent = gyakorlat.getNev()
    cimkek[0].textContent = gyakorlat.getIzomcsoport()
    cimkek[1].textContent = gyakorlat.getNehezseg()
}

function kiirGyakorlat(){
    document.querySelector(".gyakorlatok").innerHTML = ""
    for (let i = 0; i < lista.length; i++) {
       var b = beallitasok[i]
       document.querySelector(".gyakorlatok").innerHTML += `
              <div class="exercise-row d-flex align-items-center gap-3 mb-4">
              <div class="flex-grow-1">
                <p class="fw-semibold mb-0">${lista[i].getNev()}</p>
                <p class="profil-sub small mb-2">${lista[i].getIzomcsoport()} · ${lista[i].getNehezseg()}</p>
                <div class="d-flex flex-wrap gap-2">
                  <input type="number" class="form-control form-control-sm pill-input sorozat" value="${b.sorozat}" aria-label="Sorozat" oninput="Beallit(${i}, 'sorozat', this.value)">
                  <input type="number" class="form-control form-control-sm pill-input ismetles" value="${b.ismetles}" aria-label="Ismétlés" oninput="Beallit(${i}, 'ismetles', this.value)">
                  <input type="number" class="form-control form-control-sm pill-input pihenes" value="${b.pihenes}" aria-label="Pihenés" oninput="Beallit(${i}, 'pihenes', this.value)">
                  <input type="number" class="form-control form-control-sm pill-input suly" value="${b.suly}" aria-label="Súly" oninput="Beallit(${i}, 'suly', this.value)">
                </div>
              </div>
              <div class="d-flex flex-column gap-2">
                <button type="button" class="mini-btn" aria-label="Törlés" onclick="IdBeallit(${i})"><i class="bi bi-trash"></i></button>
              </div>
            </div>`
    }
}
function Keres(){
    var szoveg = document.querySelector(".kereso").value.trim().toLowerCase()
    kiirSzurt(f => f.getNev().toLowerCase().includes(szoveg))
}
function Felvesz(i){
    lista.push(feladatok[i])
    beallitasok.push({ sorozat: 5, ismetles: 5, pihenes: 120, suly: 80 })
    kiirGyakorlat()
}

function Beallit(i, mezo, ertek){
    beallitasok[i][mezo] = ertek
}

function IdBeallit(i){
    torlendo = i
    document.querySelector("#liveToast .gyakorlatNev").textContent = lista[i].getNev() //ez a ket sor ai
    bootstrap.Toast.getOrCreateInstance(document.getElementById("liveToast")).show()
}

function kiTorol(){
    lista = []
    beallitasok = []
    kiirGyakorlat()
}

function Torles(){
    lista.splice(torlendo, 1)
    beallitasok.splice(torlendo, 1)
    kiirGyakorlat()
}

function ModalHozzaad(){
    Felvesz(reszletIndex)
    bootstrap.Modal.getInstance(document.getElementById("reszletModal")).hide()
}

function Mentes(){
    var nevInput = document.querySelector(".tervNev")
    var nev = nevInput.value

    if (nev.trim() === "") {
        Uzenet("Adj nevet az edzéstervnek!")
        return
    }
    if (lista.length === 0) {
        Uzenet("Adj hozzá legalább egy gyakorlatot!")
        return
    }

    var edzesek = []
    for (let i = 0; i < lista.length; i++) {
        edzesek.push(new Edzes(
            lista[i].getNev(),
            lista[i].getIzomcsoport(),
            lista[i].getNehezseg(),
            beallitasok[i].sorozat,
            beallitasok[i].ismetles,
            beallitasok[i].pihenes,
            beallitasok[i].suly
        ))
    }

    mentettek.push(
        { nev: nev, gyakorlatok: edzesek }
    )
    Uzenet("Az edzésterv elmentve: " + nev)

    kiTorol()
    nevInput.value = ""
    ProfilMutat()
}

document.addEventListener("DOMContentLoaded", ()=>{
    if (document.querySelector(".feladatok")) {
        kiirFeladat()
        kiirIzomGombok()
        kiirGyakorlat()

        document.querySelector(".kereso").addEventListener('input', Keres)
        document.querySelector(".torles").addEventListener('click', Torles)
        document.querySelector("#reszletModal .probald-fill").addEventListener('click', ModalHozzaad)

        document.querySelector(".profilGomb").addEventListener('click', (e)=>{
        e.preventDefault()
        if (document.querySelector("#profil").classList.contains("d-none")) {
            ProfilMutat()
        } else {
            EpitoMutat()
        }
        })
        document.querySelector(".vissza").addEventListener('click', (e)=>{
            e.preventDefault()
            EpitoMutat()
        })

        if (window.location.hash === "#profil") {
            ProfilMutat()
        }
    }
})