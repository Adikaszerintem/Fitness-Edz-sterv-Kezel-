function felhasznalok(){
    return JSON.parse(localStorage.getItem("felhasznalok")) || []
}

function belepettNev(){
    return localStorage.getItem("belepett") || ""
}

function frissitNev(){
    var cim = document.querySelector("#profil h2")
    if (cim) {
        if (belepettNev() === "") {
            cim.textContent = "Vendég"
        } else {
            cim.textContent = belepettNev()
        }
    }
}
function regisztral(){
    var nev = document.querySelector("#regModal .regNev").value.trim()
    var email = document.querySelector("#regModal .regEmail").value.trim()
    var jelszo = document.querySelector("#regModal .regJelszo").value

    if (nev === "" || email === "" || jelszo === "") {
        Uzenet("Tölts ki minden mezőt!")
        return
    }

    var profil = new Profil(nev, email, jelszo)

    if (profil.getNev() === undefined) {
        Uzenet("A név legalább 4 karakter legyen, és nem lehet benne speciális karakter!")
        return
    }
    if (profil.getEmail() === undefined) {
        Uzenet("Hibás email cím! (kisbetűs, @gmail és .hu végződés kell)")
        return
    }
    if (profil.getJelszo() === undefined) {
        Uzenet("A jelszó legalább 9 karakter, legyen benne nagybetű, kisbetű és speciális karakter!")
        return
    }

    var tarolt = felhasznalok()
    for (let i = 0; i < tarolt.length; i++) {
        if (tarolt[i].email === profil.getEmail()) {
            Uzenet("Ez az email cím már foglalt!")
            return
        }
    }

    tarolt.push({
        nev: profil.getNev(),
        email: profil.getEmail(),
        jelszo: profil.getJelszo()
    })
    localStorage.setItem("felhasznalok", JSON.stringify(tarolt))
    localStorage.setItem("belepett", profil.getNev())

    document.querySelector("#regModal .regNev").value = ""
    document.querySelector("#regModal .regEmail").value = ""
    document.querySelector("#regModal .regJelszo").value = ""
    bootstrap.Modal.getOrCreateInstance(document.getElementById("regModal")).hide()

    Uzenet("Sikeres regisztráció: " + profil.getNev())
    frissitNev()
}

function belep(){
    var email = document.querySelector("#belepesModal .belepEmail").value.trim()
    var jelszo = document.querySelector("#belepesModal .belepJelszo").value

    var tarolt = felhasznalok()
    for (let i = 0; i < tarolt.length; i++) {
        var profil = new Profil(tarolt[i].nev, tarolt[i].email, tarolt[i].jelszo)

        if (profil.getEmail() === email && profil.getJelszo() === jelszo) {
            localStorage.setItem("belepett", profil.getNev())

            document.querySelector("#belepesModal .belepEmail").value = ""
            document.querySelector("#belepesModal .belepJelszo").value = ""
            bootstrap.Modal.getOrCreateInstance(document.getElementById("belepesModal")).hide()

            Uzenet("Üdv újra, " + profil.getNev() + "!")
            frissitNev()
            return
        }
    }
    Uzenet("Hibás email cím vagy jelszó!")
}

function kilep(){
    localStorage.removeItem("belepett")
    Uzenet("Sikeresen kijelentkeztél!")
    frissitNev()
}

document.addEventListener("DOMContentLoaded", frissitNev)

document.addEventListener('click', (e)=>{
    if (e.target.closest("#regModal .regGomb")) {
        regisztral()
    }
    else if (e.target.closest("#belepesModal .belepGomb")) {
        belep()
    }
    else if (e.target.closest(".kijelentkezes")) {
        e.preventDefault()
        kilep()
    }
})