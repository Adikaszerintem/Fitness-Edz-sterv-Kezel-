class Feladat{
    #nev
    #izomcsoport
    #nehezseg

    constructor(nev, izomcsoport, nehezseg){
        this.setNev(nev)
        this.setIzomcsoport(izomcsoport)
        this.setNehezseg(nehezseg)
    }

    setNev(nev) {
        if (nev.length < 5) {
            this.#nev = "Ismeretlen gyakorlat"
        } else {
            this.#nev = nev
        }
    }

    setIzomcsoport(izomcsoport) {
        this.#izomcsoport = izomcsoport
    }

    setNehezseg(nehezseg) {
        this.#nehezseg = nehezseg
    }

    getNev() {
        return this.#nev
    }

    getIzomcsoport() {
        return this.#izomcsoport
    }

    getNehezseg() {
        return this.#nehezseg
    }

    toString(){
        return `${this.getNev()}, ${this.getIzomcsoport()}, ${this.getNehezseg()}`
    }
}