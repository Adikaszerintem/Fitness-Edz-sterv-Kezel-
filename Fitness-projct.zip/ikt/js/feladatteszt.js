var feladat = new Feladat("Kétkezes súlyzós evezés", "Hat", "Konnyu")

console.assert(feladat.toString() === "Kétkezes súlyzós evezés, Hat, Konnyu", "Hiba van a getter/setter metodusokban")