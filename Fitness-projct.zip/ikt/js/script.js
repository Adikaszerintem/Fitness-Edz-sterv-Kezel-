
var temp = ""
document.querySelector(".Bejelentkezes").addEventListener('click', ()=>{
var body = document.querySelector("main")
 temp = body.innerHTML
body.innerHTML =
    `

<section class="mb-5 profil" id="profil">
    <div class="container">


        <div class="d-flex justify-content-between align-items-center mb-4">
            <a href="#" class="profil-icon vissza" aria-label="Vissza"><i class="bi bi-arrow-left"></i></a>

            <div class="dropdown">
                <button class="profil-icon dropdown-toggle-no-caret" type="button" data-bs-toggle="dropdown"
                    aria-expanded="false" aria-label="Menü">
                    <i class="bi bi-person-circle"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><button class="dropdown-item" type="button" data-bs-toggle="modal"
                            data-bs-target="#belepesModal">Bejelentkezés</button></li>
                    <li><button class="dropdown-item" type="button" data-bs-toggle="modal"
                            data-bs-target="#regModal">Regisztráció</button></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="#">Kijelentkezés</a></li>
                </ul>
            </div>
        </div>

        <div class="text-center mb-5">
            <div class="avatar mx-auto mb-3"><i class="bi bi-person-fill"></i></div>
            <h2 class="fs-3 mb-1">Kovács Márk</h2>
            <p class="mb-0 profil-sub">Hobbi sportoló · Tag 2025 óta</p>
        </div>

        <div class="profil-panel p-4 mb-4">
            <h3 class="fs-5 mb-3">Heti edzésnapló</h3>
            <div class="table-responsive">
                <table class="table table-borderless align-middle mb-0 profil-table">
                    <thead>
                        <tr>
                            <th>Nap</th>
                            <th>Edzés</th>
                            <th>Időtartam</th>
                            <th>Összsúly</th>
                            <th>Állapot</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Hétfő</td>
                            <td>Mell + tricepsz</td>
                            <td>62 perc</td>
                            <td>8 450 kg</td>
                            <td>Kész</td>
                        </tr>
                        <tr>
                            <td>Szerda</td>
                            <td>Hát + bicepsz</td>
                            <td>58 perc</td>
                            <td>7 920 kg</td>
                            <td>Kész</td>
                        </tr>
                        <tr>
                            <td>Péntek</td>
                            <td>Láb</td>
                            <td>71 perc</td>
                            <td>12 300 kg</td>
                            <td>Kész</td>
                        </tr>
                        <tr>
                            <td>Szombat</td>
                            <td>Váll + core</td>
                            <td>–</td>
                            <td>–</td>
                            <td>Tervezett</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <p class="profil-sub mb-2">Személyes rekordok</p>

        <div class="row g-3">
            <div class="col-12 col-md-3">
                <div
                    class="profil-panel p-4 h-100 text-center d-flex flex-column justify-content-center align-items-center ">
                    <i class="bi bi-trophy fs-1"></i>
                    <p class="fs-2 fw-bold mb-0">150</p>
                    <p class="profil-sub mb-0">edzés összesen</p>
                </div>
            </div>
            <div class="col-12 col-md-9">
                <div class="profil-panel p-4 h-100">
                    <div class="table-responsive">
                        <table class="table table-borderless align-middle mb-0 profil-table">
                            <thead>
                                <tr>
                                    <th>Gyakorlat</th>
                                    <th>Súly</th>
                                    <th>Ismétlés</th>
                                    <th>Dátum</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Guggolás</td>
                                    <td>120 kg</td>
                                    <td>5</td>
                                    <td>2026.09.28.</td>
                                </tr>
                                <tr>
                                    <td>Fekvenyomás</td>
                                    <td>95 kg</td>
                                    <td>5</td>
                                    <td>2026.10.02.</td>
                                </tr>
                                <tr>
                                    <td>Felhúzás</td>
                                    <td>150 kg</td>
                                    <td>3</td>
                                    <td>2026.10.09.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

 
</section>`
    ;
    document.querySelector(".vissza").addEventListener('click', ()=>{
    body.innerHTML = temp
})

})
function kiir(){
    document.querySelector(".feladatok").innerHTML = ""
    for (let i = 0; i < feladatok.length; i++) {
       document.querySelector(".feladatok").innerHTML += `
         <div class="exercise-row d-flex align-items-center gap-3 mb-3">
              <button type="button" class="catalog-item flex-grow-1" data-bs-toggle="modal" data-bs-target="#reszletModal">
                <span class="fw-semibold d-block">${feladatok[i].getNev()}}</span>
                <span class="profil-sub small">${feladatok[i].getIzomcsoport()} · ${feladatok[i].getNehezseg()}</span>
              </button>
              <button type="button" class="mini-btn" aria-label="Hozzáadás"><i class="bi bi-plus-lg"></i></button>
            </div>`
        
    }

}
kiir()